package com.cts.wios.exceptions;
@SuppressWarnings("serial")
public class SpaceNotAvailable extends Exception{
	public SpaceNotAvailable(String message) {
		super(message);
	}
 
}
