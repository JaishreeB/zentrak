package com.cts.wios.dto;

public class NotifyStockReponseDTO {

}
