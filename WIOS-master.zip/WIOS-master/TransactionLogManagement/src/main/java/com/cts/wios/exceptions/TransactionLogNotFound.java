package com.cts.wios.exceptions;
@SuppressWarnings("serial")
public class TransactionLogNotFound extends Exception {
	public TransactionLogNotFound(String message) {
		super(message);
	}
}