package com.cts.wios.exceptions;
@SuppressWarnings("serial")
public class ZoneNotFound extends Exception{
	public ZoneNotFound(String message) {
		super(message);
	}
}