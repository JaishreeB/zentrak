package com.cts.wios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendorManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendorManagementServiceApplication.class, args);
	}

}
