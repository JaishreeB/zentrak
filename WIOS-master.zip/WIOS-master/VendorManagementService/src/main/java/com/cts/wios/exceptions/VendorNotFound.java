package com.cts.wios.exceptions;

@SuppressWarnings("serial")
public class VendorNotFound extends Exception{
	public VendorNotFound(String message) {
		super(message);
	}

}
