package com.cts.wios.dto;

import java.util.List;

import com.cts.wios.model.PerformanceMetrics;

public class MetricsTransactionResponseDTO {

	private List<TransactionLog> transactions;

	private PerformanceMetrics metric;
}
