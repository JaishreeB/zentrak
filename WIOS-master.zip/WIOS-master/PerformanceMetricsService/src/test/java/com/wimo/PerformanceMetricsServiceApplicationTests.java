package com.wimo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerformanceMetricsServiceApplicationTests {
	/*
	 * default test case
	 */
	@Test
	void contextLoads() {
	}

}
