package com.exceptions;

@SuppressWarnings("serial")
public class UserRoleNotFound extends Exception{
	
	public UserRoleNotFound(String message) {
		super(message);
	}

}
