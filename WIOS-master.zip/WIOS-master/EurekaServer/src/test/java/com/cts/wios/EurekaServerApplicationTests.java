package com.cts.wios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerApplicationTests {
	/*
	 * default test case
	 */
	@Test
	void contextLoads() {
	}

	
}
