import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { LoginService } from '../login.service';
import { CommonServiceService } from '../common-service.service';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NotificationService } from '../notification.service';

@Component({
  selector: 'header',
  imports: [CommonModule,RouterModule,RouterOutlet,RouterLink],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})

export class HeaderComponent {
  
  constructor(private loginService:LoginService,private commonService:CommonServiceService,private notificationService:NotificationService){
   
  }

  
  logout(){
    sessionStorage.clear() 
    return this.loginService.logout();
   }
 
  get isAdmin():boolean{
    if(this.commonService.getUserRole()=="ADMIN"){
      return true;
    }
  }
  get isLogedIn(): boolean{
    if(this.commonService.getToken()){
      return true;
    }
    else{
      return this.loginService.getLoginStatus();
    }
  }

   get notificationCount(): number {
    // this.notificationService.getNotifications().subscribe(data => {
    //   this.notificationService.notificationCount = data.length;
    // });
    return this.notificationService.notificationCount;
  }

}
